#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

MOD_DIR="native-mods/grassier-grass"
mkdir -p "$MOD_DIR/src/mod" .github/workflows

cat > "$MOD_DIR/CMakeLists.txt" <<'CMAKE'
cmake_minimum_required(VERSION 3.22)
project(grassier_grass LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

if(NOT ANDROID)
    message(FATAL_ERROR "Grassier Grass must be built with the Android NDK toolchain.")
endif()

if(NOT CMAKE_ANDROID_ARCH_ABI STREQUAL "armeabi-v7a")
    message(FATAL_ERROR "This project targets armeabi-v7a only; got ${CMAKE_ANDROID_ARCH_ABI}.")
endif()

set(MOD_ID "grassier_grass")
set(MOD_NAME "Grassier Grass (ARMv7)")
set(MOD_AUTHOR "Independent LeviLauncher port")
set(MOD_VERSION "0.1.0-probe")
set(MOD_LIBRARY_NAME "grassier_grass")
set(MOD_MINECRAFT_VERSIONS "[\"1.26.62.*\"]")

include(FetchContent)
FetchContent_Declare(
    preloader_android_32bit
    GIT_REPOSITORY https://github.com/mynameisgoodlen/preloader-android-32bit.git
    GIT_TAG 492de78cb0ed2c71074ba12bd41cf60862388e6c
)
FetchContent_MakeAvailable(preloader_android_32bit)

add_library(${MOD_LIBRARY_NAME} SHARED
    src/main.cpp
    src/mod/GrassierGrass.cpp
)

set_target_properties(${MOD_LIBRARY_NAME} PROPERTIES
    OUTPUT_NAME "${MOD_LIBRARY_NAME}"
    CXX_VISIBILITY_PRESET hidden
    VISIBILITY_INLINES_HIDDEN YES
)

target_include_directories(${MOD_LIBRARY_NAME} PRIVATE
    "${CMAKE_CURRENT_SOURCE_DIR}/src"
)

target_compile_options(${MOD_LIBRARY_NAME} PRIVATE
    -Wall -Wextra -Wpedantic
    -fvisibility=hidden
    -fvisibility-inlines-hidden
)

target_link_options(${MOD_LIBRARY_NAME} PRIVATE
    "-Wl,-z,max-page-size=16384"
)

find_library(ANDROID_LOG_LIB log REQUIRED)
find_library(ANDROID_EGL_LIB EGL REQUIRED)
find_library(ANDROID_GLES_LIB GLESv3 REQUIRED)
find_library(ANDROID_LIB android REQUIRED)

target_link_libraries(${MOD_LIBRARY_NAME} PRIVATE
    preloader
    ${ANDROID_LOG_LIB}
    ${ANDROID_EGL_LIB}
    ${ANDROID_GLES_LIB}
    ${ANDROID_LIB}
    ${CMAKE_DL_LIBS}
)

configure_file(
    "${CMAKE_CURRENT_SOURCE_DIR}/manifest.json.in"
    "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
    @ONLY
)

set(LEVI_PACKAGE_ROOT "${CMAKE_CURRENT_BINARY_DIR}/package")
set(LEVI_PACKAGE_MOD_DIR "${LEVI_PACKAGE_ROOT}/${MOD_ID}")
set(LEVI_PACKAGE_FILE "${CMAKE_CURRENT_BINARY_DIR}/${MOD_ID}-${MOD_VERSION}-armeabi-v7a.levipack")

add_custom_target(levi_package
    COMMAND "${CMAKE_COMMAND}" -E rm -rf "${LEVI_PACKAGE_ROOT}"
    COMMAND "${CMAKE_COMMAND}" -E make_directory "${LEVI_PACKAGE_MOD_DIR}"
    COMMAND "${CMAKE_COMMAND}" -E copy "$<TARGET_FILE:${MOD_LIBRARY_NAME}>" "${LEVI_PACKAGE_MOD_DIR}/lib${MOD_LIBRARY_NAME}.so"
    COMMAND "${CMAKE_COMMAND}" -E copy "${CMAKE_CURRENT_BINARY_DIR}/manifest.json" "${LEVI_PACKAGE_MOD_DIR}/manifest.json"
    COMMAND "${CMAKE_COMMAND}" -E chdir "${LEVI_PACKAGE_ROOT}" "${CMAKE_COMMAND}" -E tar "cf" "${LEVI_PACKAGE_FILE}" --format=zip "${MOD_ID}"
    DEPENDS ${MOD_LIBRARY_NAME}
    COMMENT "Packaging ${MOD_NAME} for LeviLauncher"
    VERBATIM
)
CMAKE

cat > "$MOD_DIR/manifest.json.in" <<'MANIFEST'
{
  "type": "preload-native",
  "name": "@MOD_NAME@",
  "author": "@MOD_AUTHOR@",
  "version": "@MOD_VERSION@",
  "entry": "lib@MOD_LIBRARY_NAME@.so",
  "minecraft_versions": @MOD_MINECRAFT_VERSIONS@
}
MANIFEST

cat > "$MOD_DIR/src/main.cpp" <<'CPP'
#include "mod/GrassierGrass.h"

#include <pl/Mod.hpp>

PL_REGISTER_MOD(GrassierGrassMod, GrassierGrassMod::instance());
CPP

cat > "$MOD_DIR/src/mod/GrassierGrass.h" <<'CPP'
#pragma once

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>

class GrassierGrassMod {
public:
    static GrassierGrassMod &instance();

    GrassierGrassMod();
    GrassierGrassMod(const GrassierGrassMod &) = delete;
    GrassierGrassMod &operator=(const GrassierGrassMod &) = delete;

    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    bool installHooks();
    void removeHooks();
    void closeLibraries();

    ll::mod::NativeMod &mSelf;
    void *mEglLibrary{};
    void *mGlesLibrary{};

    pl::memory::HookHandle mShaderSourceHook;
    pl::memory::HookHandle mLinkProgramHook;
    pl::memory::HookHandle mDrawElementsHook;
    pl::memory::HookHandle mDrawArraysHook;
    pl::memory::HookHandle mBufferDataHook;
};
CPP

cat > "$MOD_DIR/src/mod/GrassierGrass.cpp" <<'CPP'
#include "mod/GrassierGrass.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#include <mutex>
#include <string>
#include <string_view>

#include <pl/Logger.hpp>

namespace {

using ShaderSourceFn = void (*)(GLuint, GLsizei, const GLchar *const *, const GLint *);
using LinkProgramFn = void (*)(GLuint);
using DrawElementsFn = void (*)(GLenum, GLsizei, GLenum, const void *);
using DrawArraysFn = void (*)(GLenum, GLint, GLsizei);
using BufferDataFn = void (*)(GLenum, GLsizeiptr, const void *, GLenum);

std::atomic<pl::log::Logger *> gLogger{nullptr};
std::atomic<bool> gEnabled{false};
std::atomic<std::uint64_t> gDrawElementsCalls{0};
std::atomic<std::uint64_t> gDrawArraysCalls{0};
std::atomic<std::uint64_t> gBufferDataCalls{0};
std::atomic<std::uint32_t> gDrawSamples{0};
std::atomic<std::uint32_t> gShaderSamples{0};
std::atomic<std::uint32_t> gProgramSamples{0};
std::atomic<std::uint32_t> gBufferSamples{0};
std::atomic<std::int64_t> gEnableTimeNs{0};

void *gOriginalShaderSource{};
void *gOriginalLinkProgram{};
void *gOriginalDrawElements{};
void *gOriginalDrawArrays{};
void *gOriginalBufferData{};

std::mutex gSeenMutex;
std::array<GLuint, 96> gSeenShaders{};
std::array<GLuint, 96> gSeenPrograms{};
std::size_t gSeenShaderCount{};
std::size_t gSeenProgramCount{};

bool firstSeen(std::array<GLuint, 96> &items, std::size_t &count, GLuint value) {
    std::lock_guard<std::mutex> lock(gSeenMutex);
    for (std::size_t i = 0; i < count; ++i) {
        if (items[i] == value) return false;
    }
    if (count >= items.size()) return false;
    items[count++] = value;
    return true;
}

pl::log::Logger *logger() {
    return gLogger.load(std::memory_order_acquire);
}

std::int64_t steadyNowNs() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

bool captureWindowOpen() {
    if (!gEnabled.load(std::memory_order_relaxed)) return false;
    const auto start = gEnableTimeNs.load(std::memory_order_relaxed);
    if (start == 0) return false;
    const auto elapsed = steadyNowNs() - start;
    // Give the player time to enter a world before collecting render calls.
    return elapsed >= 35'000'000'000LL && elapsed <= 420'000'000'000LL;
}

void logShaderSource(GLuint shader, GLsizei count,
                     const GLchar *const *strings, const GLint *lengths) {
    auto *log = logger();
    if (!log || !strings || count <= 0 || !firstSeen(gSeenShaders, gSeenShaderCount, shader)) return;

    GLint shaderType = 0;
    glGetShaderiv(shader, GL_SHADER_TYPE, &shaderType);
    const char *stage = shaderType == GL_VERTEX_SHADER ? "vertex" :
                        shaderType == GL_FRAGMENT_SHADER ? "fragment" : "other";

    std::string source;
    source.reserve(1400);
    for (GLsizei i = 0; i < count && source.size() < 1200; ++i) {
        if (!strings[i]) continue;
        const std::size_t available = lengths && lengths[i] >= 0
            ? static_cast<std::size_t>(lengths[i]) : std::strlen(strings[i]);
        const std::size_t take = std::min<std::size_t>(available, 1200 - source.size());
        source.append(strings[i], take);
        if (source.size() < 1200) source.push_back('\n');
    }

    const auto sample = gShaderSamples.fetch_add(1, std::memory_order_relaxed);
    if (sample < 64) {
        log->info("GG_SHADER id={} stage={} source_begin\n{}\nGG_SHADER_END", shader, stage, source);
    }
}

void shaderSourceDetour(GLuint shader, GLsizei count,
                        const GLchar *const *strings, const GLint *lengths) {
    if (gEnabled.load(std::memory_order_relaxed)) logShaderSource(shader, count, strings, lengths);
    const auto original = reinterpret_cast<ShaderSourceFn>(gOriginalShaderSource);
    if (original) original(shader, count, strings, lengths);
}

void logProgramLayout(GLuint program) {
    auto *log = logger();
    if (!log || !firstSeen(gSeenPrograms, gSeenProgramCount, program)) return;

    GLint linked = GL_FALSE;
    glGetProgramiv(program, GL_LINK_STATUS, &linked);
    GLint attributeCount = 0;
    GLint uniformCount = 0;
    glGetProgramiv(program, GL_ACTIVE_ATTRIBUTES, &attributeCount);
    glGetProgramiv(program, GL_ACTIVE_UNIFORMS, &uniformCount);

    const auto sample = gProgramSamples.fetch_add(1, std::memory_order_relaxed);
    if (sample >= 64) return;

    log->info("GG_PROGRAM id={} linked={} active_attributes={} active_uniforms={}",
              program, linked == GL_TRUE, attributeCount, uniformCount);

    std::array<GLchar, 160> name{};
    for (GLint i = 0; i < std::min(attributeCount, 12); ++i) {
        GLsizei length = 0;
        GLint size = 0;
        GLenum type = 0;
        glGetActiveAttrib(program, static_cast<GLuint>(i),
                          static_cast<GLsizei>(name.size()), &length, &size,
                          &type, name.data());
        if (length > 0) {
            const GLint location = glGetAttribLocation(program, name.data());
            log->info("GG_ATTR program={} name={} location={} type={} size={}",
                      program, name.data(), location, type, size);
        }
    }

    for (GLint i = 0; i < std::min(uniformCount, 12); ++i) {
        GLsizei length = 0;
        GLint size = 0;
        GLenum type = 0;
        glGetActiveUniform(program, static_cast<GLuint>(i),
                           static_cast<GLsizei>(name.size()), &length, &size,
                           &type, name.data());
        if (length > 0) {
            const GLint location = glGetUniformLocation(program, name.data());
            log->info("GG_UNIFORM program={} name={} location={} type={} size={}",
                      program, name.data(), location, type, size);
        }
    }
}

void linkProgramDetour(GLuint program) {
    const auto original = reinterpret_cast<LinkProgramFn>(gOriginalLinkProgram);
    if (original) original(program);
    if (gEnabled.load(std::memory_order_relaxed)) logProgramLayout(program);
}

void logDrawState(const char *kind, GLenum mode, GLsizei count,
                  GLenum indexType, const void *indices, GLint first) {
    auto *log = logger();
    if (!log || !captureWindowOpen()) return;

    const auto sequence = kind[0] == 'E'
        ? gDrawElementsCalls.fetch_add(1, std::memory_order_relaxed) + 1
        : gDrawArraysCalls.fetch_add(1, std::memory_order_relaxed) + 1;
    // Sampling is deliberately sparse: render-thread instrumentation must stay cheap.
    if ((sequence % 32768u) != 0u) return;
    const auto sample = gDrawSamples.fetch_add(1, std::memory_order_relaxed);
    if (sample >= 128) return;

    GLint currentProgram = 0;
    GLint arrayBuffer = 0;
    GLint elementBuffer = 0;
    GLint activeTexture = 0;
    GLint boundTexture = 0;
    GLint viewport[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_CURRENT_PROGRAM, &currentProgram);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &arrayBuffer);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &elementBuffer);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &activeTexture);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &boundTexture);
    glGetIntegerv(GL_VIEWPORT, viewport);

    const auto pointerOffset = reinterpret_cast<std::uintptr_t>(indices);
    log->info("GG_DRAW sample={} kind={} mode={} count={} index_type={} first={} indices_offset={} program={} array_buffer={} element_buffer={} active_texture={} texture_2d={} viewport={},{},{},{}",
              sample, kind, mode, count, indexType, first, pointerOffset,
              currentProgram, arrayBuffer, elementBuffer, activeTexture,
              boundTexture, viewport[0], viewport[1], viewport[2], viewport[3]);

    for (GLuint index = 0; index < 8; ++index) {
        GLint enabled = GL_FALSE;
        GLint size = 0;
        GLint type = 0;
        GLint stride = 0;
        GLint attribBuffer = 0;
        void *pointer = nullptr;
        glGetVertexAttribiv(index, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &enabled);
        if (enabled != GL_TRUE) continue;
        glGetVertexAttribiv(index, GL_VERTEX_ATTRIB_ARRAY_SIZE, &size);
        glGetVertexAttribiv(index, GL_VERTEX_ATTRIB_ARRAY_TYPE, &type);
        glGetVertexAttribiv(index, GL_VERTEX_ATTRIB_ARRAY_STRIDE, &stride);
        glGetVertexAttribiv(index, GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING, &attribBuffer);
        glGetVertexAttribPointerv(index, GL_VERTEX_ATTRIB_ARRAY_POINTER, &pointer);
        log->info("GG_VERTEX_ATTR index={} enabled=1 size={} type={} stride={} vbo={} offset={}",
                  index, size, type, stride, attribBuffer,
                  reinterpret_cast<std::uintptr_t>(pointer));
    }
}

void drawElementsDetour(GLenum mode, GLsizei count, GLenum type,
                        const void *indices) {
    logDrawState("Elements", mode, count, type, indices, 0);
    const auto original = reinterpret_cast<DrawElementsFn>(gOriginalDrawElements);
    if (original) original(mode, count, type, indices);
}

void drawArraysDetour(GLenum mode, GLint first, GLsizei count) {
    logDrawState("Arrays", mode, count, 0, nullptr, first);
    const auto original = reinterpret_cast<DrawArraysFn>(gOriginalDrawArrays);
    if (original) original(mode, first, count);
}

void bufferDataDetour(GLenum target, GLsizeiptr size,
                      const void *data, GLenum usage) {
    if (captureWindowOpen() && size >= 1024) {
        const auto sequence = gBufferDataCalls.fetch_add(1, std::memory_order_relaxed) + 1;
        const auto sample = gBufferSamples.load(std::memory_order_relaxed);
        if ((sequence % 512u) == 0u && sample < 48) {
            GLint boundBuffer = 0;
            const GLenum binding = target == GL_ELEMENT_ARRAY_BUFFER
                ? GL_ELEMENT_ARRAY_BUFFER_BINDING : GL_ARRAY_BUFFER_BINDING;
            glGetIntegerv(binding, &boundBuffer);
            const auto index = gBufferSamples.fetch_add(1, std::memory_order_relaxed);
            if (auto *log = logger()) {
                log->info("GG_BUFFER sample={} target={} buffer={} bytes={} usage={} data_present={}",
                          index, target, boundBuffer, static_cast<long long>(size),
                          usage, data != nullptr);
            }
        }
    }
    const auto original = reinterpret_cast<BufferDataFn>(gOriginalBufferData);
    if (original) original(target, size, data, usage);
}

void *resolveGlSymbol(void *library, const char *name) {
    void *symbol = library ? dlsym(library, name) : nullptr;
    if (!symbol) {
        const auto proc = eglGetProcAddress(name);
        symbol = reinterpret_cast<void *>(proc);
    }
    return symbol;
}

} // namespace

GrassierGrassMod &GrassierGrassMod::instance() {
    static GrassierGrassMod mod;
    return mod;
}

GrassierGrassMod::GrassierGrassMod()
    : mSelf(*ll::mod::NativeMod::current()) {}

bool GrassierGrassMod::load() {
    mSelf.getLogger().info("Grassier Grass ARMv7 project loaded (diagnostic stage)");
    return true;
}

bool GrassierGrassMod::enable() {
    gLogger.store(&mSelf.getLogger(), std::memory_order_release);
    gDrawElementsCalls.store(0, std::memory_order_relaxed);
    gDrawArraysCalls.store(0, std::memory_order_relaxed);
    gDrawSamples.store(0, std::memory_order_relaxed);
    gBufferSamples.store(0, std::memory_order_relaxed);
    gShaderSamples.store(0, std::memory_order_relaxed);
    gProgramSamples.store(0, std::memory_order_relaxed);
    gBufferDataCalls.store(0, std::memory_order_relaxed);
    {
        std::lock_guard<std::mutex> lock(gSeenMutex);
        gSeenShaderCount = 0;
        gSeenProgramCount = 0;
        gSeenShaders.fill(0);
        gSeenPrograms.fill(0);
    }
    gEnableTimeNs.store(steadyNowNs(), std::memory_order_relaxed);
    gEnabled.store(true, std::memory_order_release);

    const bool hooksReady = installHooks();
    mSelf.getLogger().info(
        "Grassier Grass diagnostic hooks {}. No game rendering state is modified; this build does not add visible grass yet.",
        hooksReady ? "installed" : "partially installed");
    return true;
}

bool GrassierGrassMod::disable() {
    gEnabled.store(false, std::memory_order_release);
    removeHooks();
    gLogger.store(nullptr, std::memory_order_release);
    return true;
}

bool GrassierGrassMod::unload() {
    disable();
    closeLibraries();
    mSelf.getLogger().info("Grassier Grass diagnostic mod unloaded");
    return true;
}

bool GrassierGrassMod::installHooks() {
    if (!mEglLibrary) mEglLibrary = dlopen("libEGL.so", RTLD_NOW | RTLD_LOCAL);
    if (!mGlesLibrary) mGlesLibrary = dlopen("libGLESv3.so", RTLD_NOW | RTLD_LOCAL);
    if (!mGlesLibrary) mGlesLibrary = dlopen("libGLESv2.so", RTLD_NOW | RTLD_LOCAL);

    if (!mEglLibrary || !mGlesLibrary) {
        const char *error = dlerror();
        mSelf.getLogger().error("Could not open EGL/GLES libraries: {}",
                                error ? error : "unknown error");
        return false;
    }

    auto install = [&](const char *name, void *detour, void **original,
                       pl::memory::HookHandle &handle) {
        void *target = resolveGlSymbol(mGlesLibrary, name);
        if (!target) {
            mSelf.getLogger().warn("Renderer probe could not resolve {}", name);
            return false;
        }
        handle = pl::memory::HookHandle(
            target, detour, reinterpret_cast<pl::memory::FuncPtr *>(original));
        if (!handle.installed()) {
            mSelf.getLogger().warn("Renderer probe could not hook {}", name);
            return false;
        }
        mSelf.getLogger().debug("Renderer probe hooked {}", name);
        return true;
    };

    bool ready = true;
    ready &= install("glShaderSource", reinterpret_cast<void *>(&shaderSourceDetour),
                     &gOriginalShaderSource, mShaderSourceHook);
    ready &= install("glLinkProgram", reinterpret_cast<void *>(&linkProgramDetour),
                     &gOriginalLinkProgram, mLinkProgramHook);
    ready &= install("glDrawElements", reinterpret_cast<void *>(&drawElementsDetour),
                     &gOriginalDrawElements, mDrawElementsHook);
    ready &= install("glDrawArrays", reinterpret_cast<void *>(&drawArraysDetour),
                     &gOriginalDrawArrays, mDrawArraysHook);
    ready &= install("glBufferData", reinterpret_cast<void *>(&bufferDataDetour),
                     &gOriginalBufferData, mBufferDataHook);
    return ready;
}

void GrassierGrassMod::removeHooks() {
    mShaderSourceHook.reset();
    mLinkProgramHook.reset();
    mDrawElementsHook.reset();
    mDrawArraysHook.reset();
    mBufferDataHook.reset();

    gOriginalShaderSource = nullptr;
    gOriginalLinkProgram = nullptr;
    gOriginalDrawElements = nullptr;
    gOriginalDrawArrays = nullptr;
    gOriginalBufferData = nullptr;
}

void GrassierGrassMod::closeLibraries() {
    if (mGlesLibrary) {
        dlclose(mGlesLibrary);
        mGlesLibrary = nullptr;
    }
    if (mEglLibrary) {
        dlclose(mEglLibrary);
        mEglLibrary = nullptr;
    }
}
CPP

cat > "$MOD_DIR/README.md" <<'README'
# Grassier Grass — ARMv7 LeviLauncher project

Target: the community ARMv7 LeviLauncher fork, POCO C3 / Android 10, Minecraft Bedrock `1.26.62.1`.

## Visual target

The finished feature is intended to add naturally distributed, moderately short 3D grass blades to ordinary grass blocks, with gentle wind motion and a small movement/contact response. It must not replace the grass-block texture, change water, alter other terrain, or add a user-facing configuration panel.

## Current package: renderer-diagnostic stage only

**This first package does not add visible grass.** It is a low-frequency renderer probe, not a fake visual preview. It records a small sample of:

- Vertex and fragment shader source snippets;
- Linked shader program attribute and uniform names;
- Draw mode/count and current shader program;
- Vertex/index buffer IDs and vertex attribute layouts;
- Large vertex/index buffer allocation sizes.

The hooks call the original GLES functions and do not change game render state. Sampling begins 35 seconds after the mod is enabled and stops after seven minutes or 128 draw samples. This window is intended to include a loaded world rather than only the launcher menu.

Why this stage is necessary: the public Preloader SDK provides a native lifecycle and function-hook API, but it does not provide a documented Bedrock grass/chunk mesh callback. The target's exact ARMv7 `libminecraftpe.so` renderer layout is not present in this repository. Creating extra 3D blade geometry safely requires identifying the actual terrain mesh layout and grass atlas region for this exact game build. Replacing textures or merely waving the existing flat grass geometry would not meet the requested look, so this project deliberately avoids those shortcuts.

The original Grassier Grass project is Java Edition software. This is an independent native Bedrock implementation plan; no original source code or assets are copied.

## Build

The GitHub Actions workflow builds only `armeabi-v7a`, packages a `.levipack`, verifies the ELF machine type, and uploads the artifact. It pins the user's custom 32-bit Preloader SDK at commit `492de78cb0ed2c71074ba12bd41cf60862388e6c`.

Import the artifact through LeviLauncher's Mods page. For the next implementation pass, collect the Android log after entering a grassy world and moving around for at least one minute. Search for log tags/messages beginning with `Grassier Grass` / `GG_`; these records are what let us implement a real 3D mesh insertion path rather than guessing offsets or vertex formats.
README

cat > .github/workflows/build-grassier-grass-armv7.yml <<'YAML'
name: Build Grassier Grass (ARMv7)

on:
  push:
    paths:
      - 'native-mods/grassier-grass/**'
      - '.github/workflows/build-grassier-grass-armv7.yml'
  pull_request:
    paths:
      - 'native-mods/grassier-grass/**'
      - '.github/workflows/build-grassier-grass-armv7.yml'
  workflow_dispatch:

permissions:
  contents: read

env:
  ANDROID_PLATFORM: android-29
  ANDROID_NDK_VERSION: 28.2.13676358

jobs:
  build-armv7:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v7

      - name: Set up Android SDK
        uses: android-actions/setup-android@v4
        with:
          packages: platform-tools

      - name: Install Android NDK and build tools
        shell: bash
        run: |
          set -euo pipefail
          sudo apt-get update
          sudo apt-get install -y ninja-build zip unzip binutils
          sdkmanager \
            'platforms;android-29' \
            'cmake;3.22.1' \
            "ndk;${ANDROID_NDK_VERSION}"
          echo "ANDROID_NDK_HOME=${ANDROID_HOME}/ndk/${ANDROID_NDK_VERSION}" >> "$GITHUB_ENV"

      - name: Configure ARMv7
        shell: bash
        run: |
          set -euo pipefail
          cmake -S native-mods/grassier-grass -B build/grassier-grass-armv7 -G Ninja \
            -DCMAKE_TOOLCHAIN_FILE="${ANDROID_NDK_HOME}/build/cmake/android.toolchain.cmake" \
            -DANDROID_ABI=armeabi-v7a \
            -DANDROID_PLATFORM="${ANDROID_PLATFORM}" \
            -DANDROID_STL=c++_shared \
            -DCMAKE_BUILD_TYPE=Release

      - name: Build and package LeviPack
        run: cmake --build build/grassier-grass-armv7 --target levi_package --parallel 2

      - name: Verify ARMv7 library and package
        shell: bash
        run: |
          set -euo pipefail
          SO="$(find build/grassier-grass-armv7 -type f -name 'libgrassier_grass.so' -print -quit)"
          test -n "$SO"
          readelf -h "$SO" | tee /tmp/grassier-grass-elf.txt
          grep -q 'Class:.*ELF32' /tmp/grassier-grass-elf.txt
          grep -q 'Machine:.*ARM' /tmp/grassier-grass-elf.txt
          PACKAGE='build/grassier-grass-armv7/grassier_grass-0.1.0-probe-armeabi-v7a.levipack'
          test -s "$PACKAGE"
          unzip -t "$PACKAGE"
          unzip -Z1 "$PACKAGE" | grep -qx 'grassier_grass/manifest.json'
          unzip -Z1 "$PACKAGE" | grep -qx 'grassier_grass/libgrassier_grass.so'

      - name: Upload LeviPack artifact
        uses: actions/upload-artifact@v4
        with:
          name: grassier-grass-armv7-probe
          path: build/grassier-grass-armv7/grassier_grass-0.1.0-probe-armeabi-v7a.levipack
          if-no-files-found: error
          retention-days: 30
YAML

echo 'Grassier Grass ARMv7 project files generated.'
echo 'Next: commit the generated folder and workflow, then run the GitHub Actions workflow.'
