Grassier Grass ARMv7 setup bundle

This bundle contains install-grassier-grass.sh. It writes the standalone native mod project and the GitHub Actions workflow into the current Git repository.

Use it from the root of your existing mynameisgoodlen/fps-mod Codespace:

  bash install-grassier-grass.sh
  git status --short
  git add native-mods/grassier-grass .github/workflows/build-grassier-grass-armv7.yml
  git commit -m "Add Grassier Grass ARMv7 renderer probe"
  git push

Then open GitHub Actions and run "Build Grassier Grass (ARMv7)". The workflow uploads a .levipack artifact.

IMPORTANT: This initial artifact is a diagnostic probe and does not yet render visible grass. It gathers exact GLES shader/program/mesh details from your Minecraft 1.26.62.1 device so the real blade geometry can be implemented against the actual ARMv7 renderer instead of guessing. The README inside the project explains this limitation and what to capture next.
